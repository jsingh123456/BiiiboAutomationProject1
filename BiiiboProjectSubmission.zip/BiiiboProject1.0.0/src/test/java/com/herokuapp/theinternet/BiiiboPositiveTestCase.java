package com.herokuapp.theinternet;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class BiiiboPositiveTestCase {
	private WebDriver driver; 
	
	@BeforeMethod(alwaysRun = true)
	//always run annotation allows it to run otherwise the test suite is setup to only run method 
	// that 
	//if beforemethod was not included the below 
	private void setUp() { 

	System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver");
	driver = new ChromeDriver();


		// maximize browser window
	driver.manage().window().maximize();	
	}
		
	@Test
	//order below of strings matters 
	public void biiiboTest() {
		System.out.println("Starting Biiibo Test");

//		Create driver
		// System.setProperty("webdriver.chrome.driver",
		// "src/main/resources/chromedriver");
//what- the chrome driver is named , and where- is it located 
		
		
		
//		  System.setProperty("webdriver.chrome.driver",
//		  "src/main/resources/chromedriver"); WebDriver driver = new ChromeDriver();
//		  
//		  
//		  //maximize browser window 
//		  driver.manage().window().maximize();
//		 // above code was used 1) to direct to where driver is located 2) set driver to chromedriver to run test in chrome
		 // - 3) maximize the window once it was opened.
		// The following has been added to the "BeforeMethod" so it could run before every test method- this approach requires 
		// less repetative coding as drive does not have to be set up every time method is running but instead runs before every method
		//since the same driver setup is required for each method 

//		open test page
		String url = "https://develop.biiibo.net/";
		driver.get(url);
		System.out.println("Page is opened.");
		sleep(2000);
		//1. Login to the web storefront.
//		Enter search criteria into search bar 
		WebElement loginButton = driver.findElement(By.xpath("//a[@href='/login']"));
		loginButton.click();
		
		WebElement usernameField = driver.findElement(By.xpath("//input[@id='login_email']"));
		usernameField.sendKeys("qa-candidate-1@biiibo.com");
		
		WebElement passwordField = driver.findElement(By.id("login_password"));
		passwordField.sendKeys("QA-candidate-12@#");
		
//		Click  Sign-In Button 
		WebElement signInButton = driver.findElement(By.xpath("//html//div[@id='page-login']//section[@class='for-login']//form[@role='form']/button[@type='submit']"));
		signInButton.click();

	//	2. Make sure the cart is empty.
		WebElement cartValue = driver.findElement(By.id("cart-count"));
		String expectedCartValue = "0";
		String actualCartValue = cartValue.getText(); 
		Assert.assertEquals(actualCartValue,(expectedCartValue),"Cart is not empty");
		sleep(6000);
	// 3. Go to Windows and Doors
		WebElement windowsAndDoors = driver.findElement(By.xpath("//div[@id='cate-biiibo-catalogue/windows-and-doors']//a[@href='/biiibo-catalogue/windows-and-doors']/div[@class='title']"));
		windowsAndDoors.click();
		sleep(8000);
		
	//4. Add 4 - 2 Panel Shaker Door 30”x 80” x 1 ⅜”
		WebElement twoPanelDoorAddCart = driver.findElement(By.xpath("//div[@id='get_product_list_for_group']/div[@class='container']//div[@class='result']/div[5]//div[@class='div_add_to_cart_button']//button[.='Add to Cart']"));
		twoPanelDoorAddCart.click();
		sleep(2000);
		
		WebElement twoPanelDoorQuantityField = driver.findElement(By.xpath("/html//div[@id='get_product_list_for_group']//div[@class='result']/div[5]//div[@class='div_view_cart_button']/div[@class='-current-item-spinner']//div[@id='adCart']/input[@value='0']"));
		twoPanelDoorQuantityField.clear();
		twoPanelDoorQuantityField.click();
		twoPanelDoorQuantityField.sendKeys("4");
		sleep(2000);
		
	//5. Add 1 - 6 panel Textured Molded Door 28” x 80” x 1 ⅜”
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1350)", "");
		
		WebElement moreButton = driver.findElement(By.xpath("/html//div[@id='get_product_list_for_group']//button[.='More']"));
		moreButton.click();
		
		sleep(9000);
		
		js.executeScript("window.scrollBy(0,600)", "");

		sleep(2000);
		
		WebElement sixPanelDoorQuantityField = driver.findElement(By.xpath("/html//div[@id='get_product_list_for_group']/div[@class='container']//div[@class='result']/div[17]//div[@class='div_add_to_cart_button']//button[.='Add to Cart']"));
		sixPanelDoorQuantityField.click();
	//	sixPanelDoorQuantityField.clear();
		// sixPanelDoorQuantityField.sendKeys("1");
		
	//6. Search for 3M 133 Duct Tape, add 1 to the cart.
		
		WebElement searchBar = driver.findElement(By.xpath("//input[@id='searchMe2']"));
		searchBar.sendKeys("3M 133 Duct Tape");
		searchBar.sendKeys(Keys.RETURN);
		sleep(2000);
		WebElement tapeAddToCartButton = driver.findElement(By.xpath("/html//div[@id='get_product_list_for_group']/div[@class='container']//div[@class='result']/div[1]//div[@class='div_add_to_cart_button']//button[.='Add to Cart']"));
		tapeAddToCartButton.click();
		sleep(2000);
	//7. Check if My Cart is showing the correct quantity and subtotal.
		WebElement fullCart = driver.findElement(By.xpath("//div[@class='cart-icon']"));
		fullCart.click();
		
	//	WebElement okayButton = driver.findElement(By.xpath("//html/body/div[13]/button[@class='swal-button swal-button--confirm']"));
	//	okayButton.click();
	//	9. Select the White Glove option
		sleep(2000);
		WebElement nextButtonOne = driver.findElement(By.xpath("//html//div[@id='accordion']/div[1]/div[@class='cart-container-accordion']/div[@class='accordion-panel']/div[2]//div[@class='multi-step-arrow']/div/i[@class='fa fa-angle-right']"));
		nextButtonOne.click();
		
		Select selectProjectDropdown = new Select(driver.findElement(By.xpath("//select[@id='cart_project']")));
		selectProjectDropdown.selectByVisibleText("Test Project");
		sleep(5000);
		
		WebElement okayButton = driver.findElement(By.xpath("/html/body/div[13]//button[@class='swal-button swal-button--confirm']"));
		okayButton.click();
		
		sleep(3000);
		
		WebElement nextButtonTwo = driver.findElement(By.xpath("/html//div[@id='accordion']/div[2]/div[@class='cart-container-accordion']/div[@class='accordion-panel']/div[2]//div[@class='pull-right']/div[2]/div/i[@class='fa fa-angle-right']"));
		nextButtonTwo.click();
		sleep(3000);
		
		WebElement radioButton = driver.findElement(By.xpath("/html//div[@id='accordion']/div[3]/div[@class='cart-container-accordion']/div[@class='accordion-panel']/div[2]/div[@class='panel-body']/div[@class='row']/div//div[@class='section-shipping-rule']/div[2]/div[@class='radio']/label/input[@name='shipping_rule']"));
		radioButton.click();
		
		WebElement inSixDaysRadioButton = driver.findElement(By.xpath("/html//div[@id='dlg-shipping-rule-datetime']/div[@class='modal-dialog']//div[@class='modal-body']/div[1]/div[7]/label/input[@name='shipping_rule_date']"));
		inSixDaysRadioButton.click();
		
		sleep(2000);
		WebElement submitDateButton = driver.findElement(By.id("submit-dlg-shipping-rule-datetime"));
		submitDateButton.click();
		
		WebElement nextButtonThree = driver.findElement(By.xpath("/html//div[@id='accordion']/div[3]/div[@class='cart-container-accordion']/div[@class='accordion-panel']/div[2]//div[@class='pull-right']/div[2]/div/i[@class='fa fa-angle-right']"));
		nextButtonThree.click();
		
		sleep(2000);
		
		WebElement whiteGloveOption = driver.findElement(By.xpath("/html//div[@id='accordion']/div[4]/div[@class='cart-container-accordion']/div[@class='accordion-panel']/div[2]/div[@class='panel-body']/div[@class='row']//div[@class='section-shipping-rule']/div[2]/label/input[@name='unloading_option']"));
		whiteGloveOption.click();
		
		WebElement nextButtonFour = driver.findElement(By.xpath("/html//div[@id='accordion']/div[4]/div[@class='cart-container-accordion']/div[@class='accordion-panel']/div[2]//div[@class='pull-right']/div[2]/div/i[@class='fa fa-angle-right']"));
		nextButtonFour.click();
		
		sleep(2000);
		WebElement nextButtonFive = driver.findElement(By.xpath("/html//div[@id='accordion']/div[5]/div[@class='cart-container-accordion']/div[@class='accordion-panel']/div[2]//div[@class='pull-right']/div[2]/div/i[@class='fa fa-angle-right']"));
		nextButtonFive.click();
	//	10. See if Grand Total is correctly calculated.
		sleep(2000);
		
		WebElement grandTotal = driver.findElement(By.xpath("//span[@class='tax-grand-total bold']"));
		String expectedGrandTotal = "$ 3,194.06";
		String actualGrandTotal = grandTotal.getText();
		Assert.assertEquals(actualGrandTotal,(expectedGrandTotal),"Grand total is not $ 3,194.06");

		
		
		
		
		
	}
		
		
		
		
		
		
			
		

	private void sleep(long m) {
		try {
			Thread.sleep(m);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	 	
	/*
	 * @Parameters({ "unamePositive", "PwordPositive", "expectedMessagePositive" })
	 * // the above parameter command calls the .xml NegativeTestsOnly Parameter
	 * Test // Suite, and sends parameters to it // the value comes back the
	 * paramaters are sent from //
	 * NegativeTestsOnlyParameterTestSuiteExampleCH.28.xml and when returned execute
	 * // in sequence // allowing for 'uname" being able to have 2 different values
	 * sent to it from // the xml
	 * 
	 * @Test(groups = {"PositiveTest"}) //order below of strings matters public void
	 * PositiveUsernameTest (String unamePositive, String PwordPositive, String
	 * expectedMessagePositive) { System.out.println("Starting Positive Test Case");
	 * 
	 * 
	 * //// Create driver // System.setProperty("webdriver.chrome.driver",
	 * "src/main/resources/chromedriver"); // WebDriver driver1 = new
	 * ChromeDriver(); // // // // // maximize browser window //
	 * driver1.manage().window().maximize();
	 * 
	 * // open test page String url = "http://the-internet.herokuapp.com/login";
	 * driver.get(url); System.out.println("Page is opened.");
	 * 
	 * 
	 * 
	 * // enter username WebElement username =
	 * driver.findElement(By.id("username")); username.sendKeys(unamePositive);
	 * 
	 * // enter password WebElement password =
	 * driver.findElement(By.name("password")); password.sendKeys(PwordPositive);
	 * 
	 * // click login button WebElement loginButton =
	 * driver.findElement(By.xpath("//button[@class='radius']")); //alternative code
	 * WebElement loginButton = driver.findElement(By.tagName("button"));
	 * 
	 * loginButton.click();
	 * 
	 * 
	 * // verificatins:
	 * 
	 * // new url2 String expectedUrl ="http://the-internet.herokuapp.com/secure";
	 * String actualUrl = driver.getCurrentUrl(); Assert.assertEquals(actualUrl,
	 * expectedUrl, "Actual Url is not equal to Expected Url");
	 * 
	 * // logout button is visible WebElement logoutButton =
	 * driver.findElement(By.xpath("//a[@class='button secondary radius']"));
	 * Assert.assertTrue(logoutButton.isDisplayed(),
	 * "Logout Button is Not Displaying");
	 * 
	 * // succesful login message // alternative code WebElement verificationButton
	 * = driver.findElement(By.cssSelector("#flash")); WebElement successMessage =
	 * driver.findElement(By.xpath("//div[@id='flash']")); String actualMessage =
	 * successMessage.getText(); //
	 * Assert.assertEquals(actualMessage,expectedMessage,"Actual message is not
	 * //the same as expected");
	 * Assert.assertTrue(actualMessage.contains(expectedMessagePositive)
	 * ,"Actual message doesn ot contain expected message .\nActual Message: " +
	 * actualMessage + "\nExpected Message: " +expectedMessagePositive);
	 * 
	 */
			
//			// Close browser
//			driver.quit();
			// moved and combined with afterMethod so it runs after every method with reduced code within each method 
		
	
	 	
	/*
	 * @AfterMethod (alwaysRun = true) private void tearDown() { // Close browser
	 * driver.quit(); }
	 */
}

//@Test(priority = 2, enabled = false, groups = {"NegativeTest"}) // enabled =
//false command skips this test when "NegativeTestsOnly.xml" test sutie runs
//groups = { "functest", "checkintest" command allows for specific test only
//within certain groups to be executed ex.smoketest or regression group out of
//all Positive Test Cases public void IncorrectPasswordTest() {
//System.out.println("Starting incorrect login test 2");
//
//// Create driver // System.setProperty("webdriver.chrome.driver",
//"src/main/resources/chromedriver"); //what- the chrome driver is named , and
//where- is it located System.setProperty("webdriver.chrome.driver",
//"src/main/resources/chromedriver"); WebDriver driver = new ChromeDriver();
//
//// sleep for 3 seconds sleep(3000);
//
//// maximize browser window driver.manage().window().maximize();
//
//// open test page String url = "http://the-internet.herokuapp.com/login";
//driver.get(url); System.out.println("Page is opened.");
//
//// sleep for 2 seconds sleep(2000);
//
//// enter username incorrect WebElement username =
//driver.findElement(By.id("username")); username.sendKeys("uname"); //
//hardcoded-> username.sendKeys("tomsmithh");
//
//
//
//// enter password WebElement password =
//driver.findElement(By.name("password")); password.sendKeys("incPword"); //
//hardcoded-> password.sendKeys("SuperSecretPassword!");
//
//// click login button WebElement loginButton =
//driver.findElement(By.xpath("//button[@class='radius']")); //alternative code
//WebElement loginButton = driver.findElement(By.tagName("button"));
//
//loginButton.click();
//
//
//// verificatins:
//
//// new url2 String expectedUrl ="http://the-internet.herokuapp.com/login";
//String actualUrl = driver.getCurrentUrl(); Assert.assertEquals(actualUrl,
//expectedUrl, "Actual Url is not equal to Expected Url");
//
//// unsuccessful login message WebElement unsuccessfulMessage =
//driver.findElement(By.xpath("//div[@class ='flash error']")); //for when
//expectedError was hard coded without // parameters -> String expectedError =
//"Your username is invalid!";
//
//String actualError = unsuccessfulMessage.getText();
//Assert.assertTrue(actualError.contains(expectedError),
//"Actual error is not the same as Expected error");
//
//// Close browser driver.quit(); } private void sleep(long m) { try {
//Thread.sleep(m); } catch (InterruptedException e) { //  Auto-generated
//catch block e.printStackTrace(); } }